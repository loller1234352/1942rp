DarkRP.openF1Menu = DarkRP.stub{
    name = "openF1Menu",
    description = "Open the F1 help menu.",
    parameters = {
    },
    returns = {
    },
    metatable = DarkRP
}

DarkRP.closeF1Menu = DarkRP.stub{
    name = "closeF1Menu",
    description = "Close the F1 help menu.",
    parameters = {
    },
    returns = {
    },
    metatable = DarkRP
}

DarkRP.refreshF1Menu = DarkRP.stub{
    name = "refreshF1Menu",
    description = "Close the F1 help menu.",
    parameters = {
    },
    returns = {
    },
    metatable = DarkRP
}
