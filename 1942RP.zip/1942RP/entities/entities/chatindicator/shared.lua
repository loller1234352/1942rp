ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Chat Indicator"
ENT.Author = "Drakehawke"
ENT.Spawnable = false
